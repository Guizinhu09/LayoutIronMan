package com.example.trabalho_terca

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
