import 'dart:io';

import 'package:flutter/material.dart';
import 'LayoutCard.dart';
import 'LayoutImage.dart';

void main()
{
  runApp(MaterialApp(
    home: LayoutCard(),
    //LayoutImage(),
  ));
}